Please cite this work as: 

1. Motahhir, S., Chalh, A., Ghzizal, A., Sebti, S., & Derouich, A. (2016). Modeling of photovoltaic panel by using proteus.
   Journal of Engineering Science and Technology Review, 10, 8-13.
2. Motahhir, S., Chalh, A., El Ghzizal, A., & Derouich, A. (2018). Development of a low-cost PV system using an improved INC
   algorithm and a PV panel Proteus model. Journal of Cleaner Production, 204, 355-365.

3. Motahhir, S.(2018). Contribution to the optimization of energy withdrawn from a PV panel using an Embedded System. 
   (doctoral dissertation). University sidi mohammed ben abdellah, Fez, Morocco.


For more papers and works please visit : 
https://www.researchgate.net/profile/Saad_Motahhir
